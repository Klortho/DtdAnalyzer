# This script should be sourced while the current working directory is
# the directory in which this resides.

PROJ_HOME=`pwd`

export CLASSPATH=$PROJ_HOME/bin:/pmc/JAVA/jing/bin/xercesImpl.jar
export PATH=$PROJ_HOME/script:$PATH
