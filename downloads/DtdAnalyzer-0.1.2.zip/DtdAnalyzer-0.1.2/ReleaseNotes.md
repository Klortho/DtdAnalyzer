# DtdAnalyzer Release Notes

### Enhancements

* Add count of number of elements changed, removed, and added to comparison report.
* Several enhancements to the schematron generator stylesheet

### Bug fixes

* Fixed link to home page in documentor output

## DtdAnalyzer v0.1.1 - 2012-10-15

### Enhancements

* Indent output from dtdanalyzer

### Other

* Lots of tweaks to documentation and release procedure

## DtdAnalyzer v0.1 - 2012-10-13

Initial release.
